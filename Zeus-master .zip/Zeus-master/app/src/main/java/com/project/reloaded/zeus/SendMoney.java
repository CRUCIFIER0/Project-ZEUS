package com.project.reloaded.zeus;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class SendMoney extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.send_money);

    }

}
